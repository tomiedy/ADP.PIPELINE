﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADP.Membership.Entity
{
    [Serializable]
    public class MembershipRole
    {
        public string Id_Role { get; set; }
        public string Nm_Role { get; set; }
    }
}
